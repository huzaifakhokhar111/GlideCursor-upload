package com.huzaifa.glidecursor

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import kotlin.math.abs

class CursorOverlay(context: Context) : View(context) {

    private val windowManager: WindowManager =
        context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val prefs = PreferencesHelper(context)

    // Paints
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = prefs.lineColor
        strokeCap = Paint.Cap.ROUND
    }

    private val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = prefs.maskColor
        style = Paint.Style.FILL
    }

    // Geometry state
    private var currentX = -1f
    private var targetX = -1f
    private var currentTop = -1f
    private var currentBottom = -1f
    private var isVisible = false

    // Animator
    private var animator: ValueAnimator? = null
    private val interpolator = DecelerateInterpolator(1.5f)

    // Blink state
    private var isCursorVisible = true
    private val handler = Handler(Looper.getMainLooper())
    private val blinkInterval = 530L

    private val blinkRunnable = object : Runnable {
        override fun run() {
            if (isVisible) {
                isCursorVisible = !isCursorVisible
                invalidate()
                handler.postDelayed(this, blinkInterval)
            }
        }
    }

    private val idleTimeoutRunnable = Runnable {
        // Start blinking when idle for 500ms
        handler.post(blinkRunnable)
    }

    init {
        val density = context.resources.displayMetrics.density
        linePaint.strokeWidth = prefs.lineWidthDp * density
    }

    fun attachToWindow() {
        val params = WindowManager.LayoutParams().apply {
            type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            format = PixelFormat.TRANSLUCENT
            width = WindowManager.LayoutParams.MATCH_PARENT
            height = WindowManager.LayoutParams.MATCH_PARENT
        }
        try {
            windowManager.addView(this, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun detachFromWindow() {
        handler.removeCallbacksAndMessages(null)
        animator?.cancel()
        try {
            windowManager.removeView(this)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun reloadPreferences() {
        val density = context.resources.displayMetrics.density
        linePaint.color = prefs.lineColor
        linePaint.strokeWidth = prefs.lineWidthDp * density
        maskPaint.color = prefs.maskColor
        invalidate()
    }

    fun updatePosition(newX: Float, top: Float, bottom: Float) {
        if (newX <= 0f || top <= 0f || bottom <= 0f || bottom <= top) {
            hideCursor()
            return
        }

        isVisible = true
        isCursorVisible = true

        // Reset blink idle timers
        handler.removeCallbacks(blinkRunnable)
        handler.removeCallbacks(idleTimeoutRunnable)
        handler.postDelayed(idleTimeoutRunnable, 500L)

        val verticalChange = abs(top - currentTop)
        val horizontalDelta = abs(newX - targetX)

        currentTop = top
        currentBottom = bottom
        targetX = newX

        // If line changed or huge jump (more than 400px), snap immediately without gliding
        if (currentX < 0f || verticalChange > 15f || horizontalDelta > 450f) {
            animator?.cancel()
            currentX = newX
            invalidate()
            return
        }

        // Animate smooth glide from old currentX to newX
        animator?.cancel()
        animator = ValueAnimator.ofFloat(currentX, newX).apply {
            duration = prefs.glideDuration
            interpolator = this@CursorOverlay.interpolator
            addUpdateListener { va ->
                currentX = va.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun hideCursor() {
        isVisible = false
        animator?.cancel()
        currentX = -1f
        targetX = -1f
        handler.removeCallbacksAndMessages(null)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!isVisible || currentX < 0f || currentTop < 0f || currentBottom < 0f) return

        val density = context.resources.displayMetrics.density
        val maskWidth = 7f * density

        // 1. Draw mask rectangle at real caret destination to hide the native caret
        if (targetX >= 0f) {
            val maskRect = RectF(
                targetX - maskWidth / 2f,
                currentTop - 1f,
                targetX + maskWidth / 2f,
                currentBottom + 1f
            )
            canvas.drawRect(maskRect, maskPaint)
        }

        // 2. Draw animated gliding cursor line
        if (isCursorVisible) {
            canvas.drawLine(currentX, currentTop + 1f, currentX, currentBottom - 1f, linePaint)
        }
    }
}
